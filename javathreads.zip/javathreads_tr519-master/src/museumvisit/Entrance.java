package museumvisit;

public class Entrance extends MuseumSite {

  public Entrance() {
    super("Entrance");
  }

  @Override
  public boolean hasAvailability() {
    return true;
  }
}
