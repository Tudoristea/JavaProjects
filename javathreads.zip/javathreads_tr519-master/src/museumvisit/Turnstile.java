package museumvisit;

import java.util.Optional;

public class Turnstile {

  private final MuseumSite originRoom;
  private final MuseumSite destinationRoom;

  public Turnstile(MuseumSite originRoom, MuseumSite destinationRoom) {
    assert !originRoom.equals(destinationRoom);
    this.originRoom = originRoom;
    this.destinationRoom = destinationRoom;
    originRoom.addExitTurnstile(this);
  }

  public Optional<MuseumSite> passToNextRoom() {
    if (destinationRoom.hasAvailability()) {
      getOriginRoom().exit();
      getDestinationRoom().enter();
      return Optional.of(getDestinationRoom());
    }
    return Optional.empty();
  }

  public MuseumSite getOriginRoom() {
    return originRoom;
  }

  public MuseumSite getDestinationRoom() {
    return destinationRoom;
  }
}
