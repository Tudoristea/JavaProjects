import java.util.ArrayList;
import java.util.List;

public class Node {

  private String name;
  private boolean isFile;
  private List<Node> subNodes;

  // my user id is: tr519
  // this code took me x hours to complete

  // 1. name and isDirectory fields, constructor

  public Node(String name, boolean isFile) {
    nameException(name);
    subNodes = new ArrayList<>();
    this.name = name;
    this.isFile = isFile;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    nameException(name);
    this.name = name;
  }

  public boolean isFile() {
    return isFile;
  }

  public void setDirectory() {
    isFile = false;
  }

  public void setFile() {
    if (!subNodes.isEmpty()) {
      throw new IllegalArgumentException("Dir cannot be changed into files if dir != empty");
    }
    isFile = true;
  }

  // 2. Handling Inconsistent State

  private void nameException(String name) {
    if (name == null || name.length() == 0) {
      throw new IllegalArgumentException("No empty name!");
    }
    for (int i = 0; i < name.length(); i++) { // name.contains
      if (name.charAt(i) == '\n' || name.charAt(i) == '\t') {
        throw new IllegalArgumentException("No special characters!");
      }
    }
  }

  // 3. toString

  public String toString() {
    if (isFile) {
      return name;
    } else {
      return name + '/';
    }
  }


  // 4. Recursive Structure using ArrayList<Node>

  public void add(Node node) {
    if (node == null) {
      throw new IllegalArgumentException("No null nodes!");
    }
    if (isFile) {
      throw new IllegalArgumentException("Files nodes are leaves");
    }
    subNodes.add(node.clone());
  }

  // 5. Handling More Inconsistent State

// done

  // 6. Rename all to uppercase: toUpperCaseAll()

  private void toUpperCase(Node node) {
    node.name = node.name.toUpperCase();
  }

  public void toUpperCaseAll() {
    toUpperCase(this);
    for (Node child : subNodes) {
      child.toUpperCaseAll();
    }
  }
// could also use a while loop


  // 7. countAll()

  public int countAll() {
    int result = 1;
    for (Node child : subNodes) {
      result = result + child.countAll();
    }
    return result;
  }

  // 8. lsAll

  public String lsAll() {
    String str = new String();
    str = str + this.toString() + '\n';

    for (Node child : subNodes) {
      str = str + child.toString() + '\n';
      str = str + '\n';
      str = str + child.lsAll();
    }
    return str;
  }

  //9. clone
  public Node clone() {
Node nodeTwo = new Node(name, isFile);
for (Node child : subNodes) {
  Node childTwo = child.clone();
  nodeTwo.add(childTwo);
}
    return nodeTwo;
  }

  // 10. asGraphViz() method

  public String asGraphViz() {

    return "";
  }

}
