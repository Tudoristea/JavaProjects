package advancedstreams;

public class IsPalindrome {

  public static boolean isPalindrome(String string) {
    // TODO: implement as part of the suggested lab extension.
    return false;
  }
}
