package advancedstreams;

public class CubeSupplier {

  // TODO: implement this class as part of the suggested extension for the lab.

}
