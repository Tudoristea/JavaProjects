package rectangles;

import java.util.Optional;

public class Rectangle {

  private int width;
  private int height;
  // pTL is PointTopLeft
  private Point pTL;
  // pBR is PointBottomRight
  private Point pBR = new Point(0, 0);

  public Rectangle(Point pO, Point pT) {
    // pO = pointOne, pT = pointTwo
    this(new Point(Math.min(pO.getX(), pT.getX()), Math.min(pO.getY(), pT.getY())),
        Math.max(pO.getX(), pT.getX()) - Math.min(pO.getX(), pT.getX()),
        Math.max(pO.getY(), pT.getY()) - Math.min(pO.getY(), pT.getY()));
  }

  public Rectangle(Point pTL, int w, int h) {
    this.pTL = pTL;
    width = w;
    height = h;
    pBR = pBR.setX(pTL.getX() + width).setY(pTL.getY() + height);

    // this(pTL, pTL.setX(pTL.getX() + w).setY(pTL.getY() + h));
  }

  public Rectangle(int w, int h) {
    this(new Point(0, 0), w, h);
  }

  public int getWidth() {
    return width;
  }

  public int getHeight() {
    return height;
  }

  public Rectangle setWidth(int newWidth) {
    assert newWidth >= 0 : "Width value is negative";
    return new Rectangle(pTL, newWidth, height);
  }

  public Rectangle setHeight(int newHeight) {
    assert newHeight >= 0 : "Height value is negative";
    return new Rectangle(pTL, width, newHeight);
  }

  public Point getTopLeft() {
    return pTL;
  }

  public Point getTopRight() {
    return new Point(pBR.getX(), pTL.getY());
  }

  public Point getBottomLeft() {
    return new Point(pTL.getX(), pBR.getY());
  }

  public Point getBottomRight() {
    return pBR;
  }

  public int area() {
    return width * height;
  }

  private boolean isInside(Rectangle rec, Point pnt) {
    return pnt.getX() >= rec.pTL.getX() && pnt.getX() <= rec.pBR.getX() &&
           pnt.getY() >= rec.pTL.getY() && pnt.getY() <= rec.pBR.getY();
  }

  public boolean intersects(Rectangle other) {
    return isInside(this, other.getBottomLeft()) || isInside(this, other.getTopLeft()) ||
           isInside(this, other.getBottomRight()) || isInside(this, other.getTopRight());
  }

  public void updateTopLeft(Point newTopLeft) {
    Rectangle newRectangle = new Rectangle(newTopLeft, this.getWidth(), this.getHeight());
  }

  public Optional<Rectangle> intersection(Rectangle other) {
    if (this.intersects(other)) {
      Point newTopLeft = new Point(Math.max(this.getTopLeft().getX(), other.getTopLeft().getX()),
      Math.max(this.getTopLeft().getY(), other.getTopLeft().getY()));
      Point newBottomRight = new Point(Math.min(this.getBottomRight().getX(),
                                               other.getBottomRight().getX()),
          (Math.min(this.getBottomRight().getY() , other.getBottomRight().getY())));
      return Optional.of(new Rectangle(newTopLeft, newBottomRight));
    } else {
      return Optional.empty();
    }
  }

}


