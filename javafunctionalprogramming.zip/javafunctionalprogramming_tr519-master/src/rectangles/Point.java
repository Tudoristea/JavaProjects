package rectangles;

public class Point {

 private int x;
 private int y;

  public Point(int x, int y) {
    this.x = x;
    this.y = y;
  }

  public Point() {
    this(0, 0);
  }

  public Point(int x) {
    this(x, 0);
  }

  public int getX() {
    return x;
  }

  public int getY() {
    return y;
  }

  public Point setX(int x) {
    assert x >= 0 : "Negative x value";
    return new Point(x, y);
  }

  public Point setY(int y) {
    assert y >= 0 : "Negative y value";
    return new Point(x, y);
  }

  public boolean isLeftOf(Point lPoint) {
    return this.getX() < lPoint.getX();
  }

  public boolean isRightOf(Point rPoint) {
    // return !(this.isLeftOf(rPoint)); this has a bug, returns true when they are on the same
    return this.getX() > rPoint.getX();                                  // x axis
  }

  public boolean isAbove(Point aPoint) {
    return this.getY() < aPoint.getY();
  }

  public boolean isBelow(Point bPoint) {
    return this.getY() > bPoint.getY();
  }

  public Point add(Point vector) {
    return new Point(this.getX() + vector.getX(), this.getY() + vector.getY());
  }

  public boolean isEqualTo(Point otherPoint) {
    return this.getX() == otherPoint.getX() && this.getY() == otherPoint.getY();
  }

  
}
