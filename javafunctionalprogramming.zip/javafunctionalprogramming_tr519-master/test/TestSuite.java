import static java.util.stream.Collectors.toList;
import static junit.framework.TestCase.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.Test;
import rectangles.*;

public class TestSuite {

  // Un-comment when you are ready to test your Point class.

  //==================================================================================
  // Helper methods to compare points and lists of points.
  // Later in the course we will look at overriding the "equals" method of Object,
  // eliminating the need for these sorts of methods.
  //==================================================================================

  private static boolean equalPoints(Point p1, Point p2) {
    return p1.getX() == p2.getX() && p1.getY() == p2.getY();
  }

  private static boolean equalPointLists(List<Point> l1, List<Point> l2) {
    if (l1.size() != l2.size()) {
      return false;
    }
    for (int i = 0; i < l1.size(); i++) {
      if (!equalPoints(l1.get(i), l2.get(i))) {
        return false;
      }
    }
    return true;
  }

  //==========================
  // 1. Tests for Point class.
  //==========================

  @Test
  public void pointConstructor1() {
    assertTrue(equalPoints(new Point(0, 0), new Point()));
  }

  @Test
  public void pointConstructor2() {
    assertTrue(equalPoints(new Point(1, 0), new Point(1)));
  }

  @Test
  public void pointGetX() {
    assertEquals(new Point(42, 52).getX(), 42);
  }

  @Test
  public void pointGetY() {
    assertEquals(new Point(42, 52).getY(), 52);
  }

  @Test
  public void pointSetX() {
    assertTrue(equalPoints(new Point(42, 52).setX(12), new Point(12, 52)));
  }

  @Test
  public void pointSetY() {
    assertTrue(equalPoints(new Point(42, 52).setY(12), new Point(42, 12)));
  }

  @Test
  public void pointIsLeftOf() {
    assertTrue(new Point(10, 20).isLeftOf(new Point(20, 20)));
    assertFalse(new Point(10, 11).isLeftOf(new Point(10, 11)));
  }

  @Test
  public void pointIsRightOf() {
    assertTrue(new Point(10, 20).isRightOf(new Point(0, 20)));
    assertFalse(new Point(10, 11).isRightOf(new Point(12, 11)));
  }

  @Test
  public void pointIsAbove() {
    assertTrue(new Point(1, 1).isAbove(new Point(1, 2)));
    assertFalse(new Point(10, 11).isAbove(new Point(0, 0)));
  }

  @Test
  public void pointIsBelow() {
    assertTrue(new Point(1, 1).isBelow(new Point(1, 0)));
    assertFalse(new Point(10, 11).isBelow(new Point(11, 11)));
  }

  @Test
  public void pointAdd() {
    assertTrue(equalPoints(new Point(1, 1).add(new Point(10, 10)), new Point(11, 11)));
    assertTrue(equalPoints(new Point(10, 0).add(new Point(0, 10)),
        new Point(0, 10).add(new Point(10, 0))));
  }


  //==================================================================================
  // Helper methods to compare rectangles and lists of rectangles.
  // Later in the course we will look at overriding the "equals" method of Object,
  // eliminating the need for these sorts of methods.
  //==================================================================================

  private static boolean equalRectangles(Rectangle r1, Rectangle r2) {
    return equalPoints(r1.getTopLeft(), r2.getTopLeft()) &&
        equalPoints(r1.getTopRight(), r2.getTopRight()) &&
        equalPoints(r1.getBottomLeft(), r2.getBottomLeft()) &&
        equalPoints(r1.getBottomRight(), r2.getBottomRight()) &&
        r1.getWidth() == r2.getWidth() && r2.getHeight() == r2.getHeight();
  }

  private static boolean equalRectangleLists(List<Rectangle> l1, List<Rectangle> l2) {
    if (l1.size() != l2.size()) {
      return false;
    }
    for (int i = 0; i < l1.size(); i++) {
      if (!equalRectangles(l1.get(i), l2.get(i))) {
        return false;
      }
    }
    return true;
  }

  //==============================
  // 2. Tests for Rectangle class.
  //==============================

  @Test
  public void rectangleConstructor1() {
    assertTrue(equalRectangles(new Rectangle(new Point(1, 3), 4, 5),
        new Rectangle(new Point(1, 3), new Point(5, 8))));
    assertTrue(equalRectangles(new Rectangle(new Point(1, 3), 4, 5),
        new Rectangle(new Point(5, 8), new Point(1, 3))));
  }

  @Test
  public void rectangleConstructor2() {
    assertTrue(equalRectangles(new Rectangle(10, 20), new Rectangle(new Point(0, 0), 10, 20)));
    assertTrue(
        equalRectangles(new Rectangle(10, 20), new Rectangle(new Point(0, 0), new Point(10, 20))));
  }

  @Test
  public void rectangleConstructor3() {
    assertTrue(equalRectangles(
        new Rectangle(new Point(10, 1), new Point(0, 10)),
        new Rectangle(new Point(0, 1), 10, 9)));
  }

  @Test
  public void rectangleGetWidth() {
    assertEquals(new Rectangle(new Point(1, 1), new Point(11, 11)).getWidth(), 10);
    assertEquals(new Rectangle(new Point(1, 1), 20, 30).getWidth(), 20);
  }

  @Test
  public void rectangleGetHeight() {
    assertEquals(new Rectangle(new Point(1, 0), new Point(11, 11)).getHeight(), 11);
    assertEquals(new Rectangle(new Point(7, 6), 20, 30).getHeight(), 30);
  }

  @Test
  public void rectangleSetWidth() {
    assertTrue(equalRectangles(new Rectangle(new Point(1, 2), 3, 4).setWidth(5),
        new Rectangle(new Point(1, 2), 5, 4)));
    assertTrue(equalRectangles(new Rectangle(new Point(1, 2), new Point(6, 7)).setWidth(10),
        new Rectangle(new Point(1, 2), new Point(11, 7))));
  }

  @Test
  public void rectangleSetHeight() {
    assertTrue(equalRectangles(new Rectangle(new Point(1, 2), 3, 4).setHeight(5),
        new Rectangle(new Point(1, 2), 3, 5)));
    assertTrue(equalRectangles(new Rectangle(new Point(1, 2), new Point(6, 7)).setHeight(10),
        new Rectangle(new Point(1, 2), new Point(6, 12))));
  }

  @Test
  public void rectangleGetTopLeft() {
    assertTrue(equalPoints(new Point(1, 2), new Rectangle(new Point(1, 2), 3, 4).getTopLeft()));
  }

  @Test
  public void rectangleGetTopRight() {
    assertTrue(equalPoints(new Point(4, 2), new Rectangle(new Point(1, 2), 3, 4).getTopRight()));
  }

  @Test
  public void rectangleGetBottomLeft() {
    assertTrue(equalPoints(new Point(1, 6), new Rectangle(new Point(1, 2), 3, 4).getBottomLeft()));
  }

  @Test
  public void rectangleGetBottomRight() {
    assertTrue(equalPoints(new Point(4, 6), new Rectangle(new Point(1, 2), 3, 4).getBottomRight()));
  }

  @Test
  public void rectangleArea() {
    assertEquals(100, new Rectangle(10, 10).area());
    assertEquals(30, new Rectangle(new Point(), new Point(6, 5)).area());
  }

  @Test
  public void rectangleIntersect1() {
    Rectangle r1 = new Rectangle(new Point(0, 0), 10, 10);
    Rectangle r2 = new Rectangle(new Point(8, 0), 10, 10);
    Rectangle r3 = new Rectangle(new Point(0, 8), 10, 10);
    Rectangle r4 = new Rectangle(new Point(8, 8), 10, 10);

    Rectangle r5 = new Rectangle(new Point(0, 100), 5, 5);
    Rectangle r6 = new Rectangle(new Point(100, 100), 5, 5);

    assertTrue(r1.intersects(r2));
    assertTrue(r1.intersects(r3));
    assertTrue(r1.intersects(r4));
    assertTrue(r2.intersects(r3));
    assertTrue(r2.intersects(r4));
    assertTrue(r3.intersects(r4));
    assertTrue(r1.intersects(r1));
    assertTrue(r2.intersects(r2));
    assertTrue(r3.intersects(r3));
    assertTrue(r4.intersects(r4));

    assertFalse(r1.intersects(r5));
    assertFalse(r2.intersects(r5));
    assertFalse(r3.intersects(r5));
    assertFalse(r4.intersects(r5));

    assertFalse(r1.intersects(r6));
    assertFalse(r2.intersects(r6));
    assertFalse(r3.intersects(r6));
    assertFalse(r4.intersects(r6));

    assertFalse(r5.intersects(r6));

  }

  @Test
  public void rectangleIntersect2() {
    assertTrue(
        new Rectangle(new Point(0, 0), 3, 3).intersects(new Rectangle(new Point(3, 3), 10, 10)));
    assertTrue(
        new Rectangle(new Point(0, 0), 3, 3).intersects(new Rectangle(new Point(3, 0), 10, 10)));
  }

  @Test
  public void rectangleIntersect3() {
    assertFalse(
        new Rectangle(new Point(0, 0), 3, 3).intersects(new Rectangle(new Point(4, 4), 10, 10)));
  }



  //===============================================================================
  // Lists of Rectangles, useful for testing ListAlgorithms and StreamAlgorithms.
  //===============================================================================

  private static final List<Rectangle> INCREASING_ENCLOSING = Arrays.asList(
      new Rectangle(1, 1),
      new Rectangle(2, 2),
      new Rectangle(3, 3),
      new Rectangle(4, 4),
      new Rectangle(5, 5));

  private static final List<Rectangle> VARIOUS_RECTANGLES = Arrays.asList(
      new Rectangle(new Point(10, 10), 10, 10),
      new Rectangle(new Point(15, 15), 10, 10),
      new Rectangle(new Point(0, 0), 1000, 1000),
      new Rectangle(new Point(2000, 2000), 1, 1));

  private static final List<Rectangle> VARIOUS_RECTANGLES_TRANSLATED = Arrays.asList(
      new Rectangle(new Point(20, 110), 10, 10),
      new Rectangle(new Point(25, 115), 10, 10),
      new Rectangle(new Point(10, 100), 1000, 1000),
      new Rectangle(new Point(2010, 2100), 1, 1));

  private static final List<Rectangle> VARIOUS_RECTANGLES_SCALED = Arrays.asList(
      new Rectangle(new Point(10, 10), 100, 100),
      new Rectangle(new Point(15, 15), 100, 100),
      new Rectangle(new Point(0, 0), 10000, 10000),
      new Rectangle(new Point(2000, 2000), 10, 10));

  private static final List<Rectangle> VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED = Arrays.asList(
      new Rectangle(new Point(20, 110), 100, 100),
      new Rectangle(new Point(25, 115), 100, 100),
      new Rectangle(new Point(10, 100), 10000, 10000),
      new Rectangle(new Point(2010, 2100), 10, 10));


  //===================================
  // 3. Tests for ListAlgorithms class.
  //===================================

  @Test
  public void listTranslate() {
    assertTrue(equalRectangleLists(
        VARIOUS_RECTANGLES_TRANSLATED,
        ListAlgorithms.translate(VARIOUS_RECTANGLES, new Point(10, 100))));
  }

  @Test
  public void listScale() {
    assertTrue(equalRectangleLists(
        VARIOUS_RECTANGLES_SCALED, ListAlgorithms.scale(VARIOUS_RECTANGLES, 10)));
  }

  @Test
  public void listTranslateAndScale() {
    assertTrue(equalRectangleLists(
        VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED, ListAlgorithms.scale(
            ListAlgorithms.translate(VARIOUS_RECTANGLES, new Point(10, 100)),
            10)));
  }

  @Test
  public void listGetBottomLeft() {
    List<Point> bottomLeft = ListAlgorithms.getBottomLeftPoints(VARIOUS_RECTANGLES);
    List<Point> expected = Arrays.asList(
        new Point(10, 20),
        new Point(15, 25),
        new Point(0, 1000),
        new Point(2000, 2001));
    assertTrue(equalPointLists(bottomLeft, expected));
  }

  @Test
  public void listGetAllIntersecting1() {
    assertTrue(equalRectangleLists(INCREASING_ENCLOSING,
        ListAlgorithms.getAllIntersecting(INCREASING_ENCLOSING, INCREASING_ENCLOSING.get(2))));
  }

  @Test
  public void listGetAllIntersecting2() {
    assertTrue(equalRectangleLists(new ArrayList<Rectangle>(),
        ListAlgorithms.getAllIntersecting(new ArrayList<>(), new Rectangle(0, 0))));
  }

  @Test
  public void listGetAllIntersecting3() {
    Rectangle candidate = new Rectangle(new Point(3, 3), 100, 100);
    List<Rectangle> expected = Arrays
        .asList(INCREASING_ENCLOSING.get(2), INCREASING_ENCLOSING.get(3),
            INCREASING_ENCLOSING.get(4));
    assertTrue(equalRectangleLists(expected,
        ListAlgorithms.getAllIntersecting(INCREASING_ENCLOSING, candidate)));
  }

  @Test
  public void listGetAllWithBiggerAreaThan1() {
    Rectangle candidate = new Rectangle(new Point(3, 3), 100, 100);
    List<Rectangle> expected = new ArrayList<>();
    assertTrue(equalRectangleLists(expected,
        ListAlgorithms.getAllWithBiggerAreaThan(INCREASING_ENCLOSING, candidate)));
  }

  @Test
  public void listGetAllWithBiggerAreaThan2() {
    Rectangle candidate = new Rectangle(new Point(100, 100), 1, 1);
    List<Rectangle> expected = Arrays
        .asList(INCREASING_ENCLOSING.get(1), INCREASING_ENCLOSING.get(2),
            INCREASING_ENCLOSING.get(3), INCREASING_ENCLOSING.get(4));
    assertTrue(equalRectangleLists(expected,
        ListAlgorithms.getAllWithBiggerAreaThan(INCREASING_ENCLOSING, candidate)));
  }

  @Test
  public void listFindLargestArea() {
    assertEquals(5 * 5, ListAlgorithms.findLargestArea(INCREASING_ENCLOSING));
    assertEquals(1000 * 1000, ListAlgorithms.findLargestArea(VARIOUS_RECTANGLES));
    assertEquals(1000 * 1000, ListAlgorithms.findLargestArea(VARIOUS_RECTANGLES_TRANSLATED));
    assertEquals(10000 * 10000, ListAlgorithms.findLargestArea(VARIOUS_RECTANGLES_SCALED));
    assertEquals(10000 * 10000,
        ListAlgorithms.findLargestArea(VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED));
    assertEquals(0, ListAlgorithms.findLargestArea(new ArrayList<>()));
  }

  @Test
  public void listFindMaxHeight() {
    assertEquals(5, ListAlgorithms.findMaxHeight(INCREASING_ENCLOSING));
    assertEquals(1000, ListAlgorithms.findMaxHeight(VARIOUS_RECTANGLES));
    assertEquals(1000, ListAlgorithms.findMaxHeight(VARIOUS_RECTANGLES_TRANSLATED));
    assertEquals(10000, ListAlgorithms.findMaxHeight(VARIOUS_RECTANGLES_SCALED));
    assertEquals(10000, ListAlgorithms.findMaxHeight(VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED));
  }

  @Test
  public void listGetSumOfAreas() {
    assertEquals(1 * 1 + 2 * 2 + 3 * 3 + 4 * 4 + 5 * 5,
        ListAlgorithms.getSumOfAreas(INCREASING_ENCLOSING));
  }

  @Test
  public void listGetSumOfAreasOfAllIntersecting() {
    assertEquals(0, ListAlgorithms.getSumOfAreasOfAllIntersecting(INCREASING_ENCLOSING,
        new Rectangle(new Point(100, 100), 10, 10)));
    assertEquals(3 * 3 + 4 * 4 + 5 * 5, ListAlgorithms
        .getSumOfAreasOfAllIntersecting(INCREASING_ENCLOSING,
            new Rectangle(new Point(3, 3), 10, 10)));
  }

  @Test
  public void listGetAreaMap() {
    Map<Rectangle, Integer> result = ListAlgorithms.getAreaMap(INCREASING_ENCLOSING);
    Map<Rectangle, Integer> expected = new HashMap<>();
    expected.put(INCREASING_ENCLOSING.get(0), 1 * 1);
    expected.put(INCREASING_ENCLOSING.get(1), 2 * 2);
    expected.put(INCREASING_ENCLOSING.get(2), 3 * 3);
    expected.put(INCREASING_ENCLOSING.get(3), 4 * 4);
    expected.put(INCREASING_ENCLOSING.get(4), 5 * 5);

    assertEquals(expected.keySet().size(), result.keySet().size());

    for (Rectangle r : expected.keySet()) {
      assertTrue(containsMatchingPair(result, r, expected.get(r)));
    }

  }

  private boolean containsMatchingPair(Map<Rectangle, Integer> toCheck, Rectangle key,
      Integer value) {
    for (Rectangle r : toCheck.keySet()) {
      if (equalRectangles(r, key) && toCheck.get(r).equals(value)) {
        return true;
      }
    }
    return false;
  }


  //=====================================
  // 4. Tests for StreamAlgorithms class.
  //=====================================

  @Test
  public void streamTranslate() {
    assertTrue(equalRectangleLists(
        VARIOUS_RECTANGLES_TRANSLATED, StreamAlgorithms
            .translate(VARIOUS_RECTANGLES.stream(), new Point(10, 100)).collect(toList())));
  }

  @Test
  public void streamScale() {
    assertTrue(equalRectangleLists(
        VARIOUS_RECTANGLES_SCALED,
        StreamAlgorithms.scale(VARIOUS_RECTANGLES.stream(), 10).collect(toList())));
  }

  @Test
  public void streamTranslateAndScale() {
    assertTrue(equalRectangleLists(
        VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED, StreamAlgorithms.scale(
            StreamAlgorithms.translate(VARIOUS_RECTANGLES.stream(), new Point(10, 100)),
            10).collect(toList())));
  }

  @Test
  public void streamGetBottomLeft() {
    List<Point> bottomLeft = StreamAlgorithms.getBottomLeftPoints(VARIOUS_RECTANGLES.stream())
        .collect(toList());
    List<Point> expected = Arrays.asList(
        new Point(10, 20),
        new Point(15, 25),
        new Point(0, 1000),
        new Point(2000, 2001));
    assertTrue(equalPointLists(bottomLeft, expected));
  }

  @Test
  public void streamGetAllIntersecting1() {
    assertTrue(equalRectangleLists(INCREASING_ENCLOSING, StreamAlgorithms
        .getAllIntersecting(INCREASING_ENCLOSING.stream(), INCREASING_ENCLOSING.get(2))
        .collect(toList())));
  }

  @Test
  public void streamGetAllIntersecting2() {
    assertTrue(equalRectangleLists(new ArrayList<Rectangle>(), StreamAlgorithms
        .getAllIntersecting(new ArrayList<Rectangle>().stream(), new Rectangle(0, 0))
        .collect(toList())));
  }

  @Test
  public void streamGetAllIntersecting3() {
    Rectangle candidate = new Rectangle(new Point(3, 3), 100, 100);
    List<Rectangle> expected = Arrays
        .asList(INCREASING_ENCLOSING.get(2), INCREASING_ENCLOSING.get(3),
            INCREASING_ENCLOSING.get(4));
    assertTrue(equalRectangleLists(expected,
        StreamAlgorithms.getAllIntersecting(INCREASING_ENCLOSING.stream(), candidate)
            .collect(toList())));
  }

  @Test
  public void streamGetAllWithBiggerAreaThan1() {
    Rectangle candidate = new Rectangle(new Point(3, 3), 100, 100);
    List<Rectangle> expected = new ArrayList<>();
    assertTrue(equalRectangleLists(expected,
        StreamAlgorithms.getAllWithBiggerAreaThan(INCREASING_ENCLOSING.stream(), candidate).collect(
            toList())));
  }

  @Test
  public void streamGetAllWithBiggerAreaThan2() {
    Rectangle candidate = new Rectangle(new Point(100, 100), 1, 1);
    List<Rectangle> expected = Arrays
        .asList(INCREASING_ENCLOSING.get(1), INCREASING_ENCLOSING.get(2),
            INCREASING_ENCLOSING.get(3), INCREASING_ENCLOSING.get(4));
    assertTrue(equalRectangleLists(expected,
        StreamAlgorithms.getAllWithBiggerAreaThan(INCREASING_ENCLOSING.stream(), candidate)
            .collect(toList())));
  }

  @Test
  public void streamFindLargestArea() {
    assertEquals(5 * 5, StreamAlgorithms.findLargestArea(INCREASING_ENCLOSING.stream()));
    assertEquals(1000 * 1000, StreamAlgorithms.findLargestArea(VARIOUS_RECTANGLES.stream()));
    assertEquals(1000 * 1000,
        StreamAlgorithms.findLargestArea(VARIOUS_RECTANGLES_TRANSLATED.stream()));
    assertEquals(10000 * 10000,
        StreamAlgorithms.findLargestArea(VARIOUS_RECTANGLES_SCALED.stream()));
    assertEquals(10000 * 10000,
        StreamAlgorithms.findLargestArea(VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED.stream()));
    assertEquals(0, StreamAlgorithms.findLargestArea(new ArrayList<Rectangle>().stream()));
  }

  @Test
  public void streamFindMaxHeight() {
    assertEquals(5, StreamAlgorithms.findMaxHeight(INCREASING_ENCLOSING.stream()));
    assertEquals(1000, StreamAlgorithms.findMaxHeight(VARIOUS_RECTANGLES.stream()));
    assertEquals(1000, StreamAlgorithms.findMaxHeight(VARIOUS_RECTANGLES_TRANSLATED.stream()));
    assertEquals(10000, StreamAlgorithms.findMaxHeight(VARIOUS_RECTANGLES_SCALED.stream()));
    assertEquals(10000,
        StreamAlgorithms.findMaxHeight(VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED.stream()));
  }

  @Test
  public void streamGetSumOfAreas() {
    assertEquals(1 * 1 + 2 * 2 + 3 * 3 + 4 * 4 + 5 * 5,
        StreamAlgorithms.getSumOfAreas(INCREASING_ENCLOSING.stream()));
  }

  @Test
  public void streamGetSumOfAreasOfAllIntersecting() {
    assertEquals(0, StreamAlgorithms.getSumOfAreasOfAllIntersecting(INCREASING_ENCLOSING.stream(),
        new Rectangle(new Point(100, 100), 10, 10)));
    assertEquals(3 * 3 + 4 * 4 + 5 * 5, StreamAlgorithms
        .getSumOfAreasOfAllIntersecting(INCREASING_ENCLOSING.stream(),
            new Rectangle(new Point(3, 3), 10, 10)));
  }

  @Test
  public void streamGetAreaMap() {
    Map<Rectangle, Integer> result = StreamAlgorithms.getAreaMap(INCREASING_ENCLOSING.stream());
    Map<Rectangle, Integer> expected = new HashMap<>();
    expected.put(INCREASING_ENCLOSING.get(0), 1 * 1);
    expected.put(INCREASING_ENCLOSING.get(1), 2 * 2);
    expected.put(INCREASING_ENCLOSING.get(2), 3 * 3);
    expected.put(INCREASING_ENCLOSING.get(3), 4 * 4);
    expected.put(INCREASING_ENCLOSING.get(4), 5 * 5);

    assertEquals(expected.keySet().size(), result.keySet().size());

    for (Rectangle r : expected.keySet()) {
      assertTrue(containsMatchingPair(result, r, expected.get(r)));
    }

  }

  //==============================================================================
  // 5. Tests to check equivalence of ListAlgorithms and StreamAlgorithms classes.
  //==============================================================================

  private static final List<List<Rectangle>> RECTANGLE_LISTS = Arrays.asList(
      INCREASING_ENCLOSING, VARIOUS_RECTANGLES, VARIOUS_RECTANGLES_SCALED,
      VARIOUS_RECTANGLES_TRANSLATED, VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED);

  @Test
  public void compareListStreamTranslate() {

    // You should look up what "forEach" does in the Java documentation

    RECTANGLE_LISTS.forEach(l ->
        assertTrue(equalRectangleLists(
            ListAlgorithms.translate(l, new Point(20, 20)),
            StreamAlgorithms.translate(l.stream(), new Point(20, 20)).collect(toList())
        )));
  }

  @Test
  public void compareListStreamScale() {
    RECTANGLE_LISTS.forEach(l ->
        assertTrue(equalRectangleLists(
            ListAlgorithms.scale(l, 42),
            StreamAlgorithms.scale(l.stream(), 42).collect(toList())
        )));
  }

  @Test
  public void compareListStreamGetBottomLeft() {
    RECTANGLE_LISTS.forEach(l ->
        assertTrue(equalPointLists(
            ListAlgorithms.getBottomLeftPoints(l),
            StreamAlgorithms.getBottomLeftPoints(l.stream()).collect(toList())
        )));
  }

  @Test
  public void compareListStreamGetAllIntersecting() {
    RECTANGLE_LISTS.forEach(l -> {
      Rectangle intersectionCandidate = new Rectangle(new Point(2, 2), 1000, 2);
      assertTrue(equalRectangleLists(
          ListAlgorithms.getAllIntersecting(l, intersectionCandidate),
          StreamAlgorithms.getAllIntersecting(l.stream(), intersectionCandidate).collect(toList())
      ));
    });
  }

  @Test
  public void compareListStreamGetAllWithBiggerAreaThan() {
    RECTANGLE_LISTS.forEach(l -> {
      Rectangle areaCandidate = new Rectangle(new Point(2, 2), 60, 2);
      assertTrue(equalRectangleLists(
          ListAlgorithms.getAllWithBiggerAreaThan(l, areaCandidate),
          StreamAlgorithms.getAllWithBiggerAreaThan(l.stream(), areaCandidate).collect(toList())
      ));
    });
  }

  @Test
  public void compareListStreamFindLargestArea() {
    RECTANGLE_LISTS.forEach(l -> {
      assertEquals(
          ListAlgorithms.findLargestArea(l),
          StreamAlgorithms.findLargestArea(l.stream())
      );
    });
  }

  @Test
  public void compareListStreamFindMaxHeight() {
    RECTANGLE_LISTS.forEach(l -> {
      assertEquals(
          ListAlgorithms.findMaxHeight(l),
          StreamAlgorithms.findMaxHeight(l.stream())
      );
    });
  }

  @Test
  public void compareListStreamGetSumOfAreas() {
    RECTANGLE_LISTS.forEach(l -> {
      assertEquals(
          ListAlgorithms.getSumOfAreas(l),
          StreamAlgorithms.getSumOfAreas(l.stream())
      );
    });
  }

  @Test
  public void compareListStreamGetSumOfAreasOfAllIntersecting() {
    RECTANGLE_LISTS.forEach(l -> {
      Rectangle intersectionCandidate = new Rectangle(new Point(10, 10), 10, 10);
      assertEquals(
          ListAlgorithms.getSumOfAreasOfAllIntersecting(l, intersectionCandidate),
          StreamAlgorithms.getSumOfAreasOfAllIntersecting(l.stream(), intersectionCandidate)
      );
    });
  }

  //======================================
  // 6. Tests for intersecting rectangles.
  //======================================

  @Test
  public void rectangleIntersection1() {
    assertTrue(
        equalRectangles(
            new Rectangle(new Point(10, 10), 5, 5),
            new Rectangle(new Point(0, 0), 15, 15).intersection(new Rectangle(new Point(10, 10), 15, 15)).get()
    ));
  }

  @Test
  public void rectangleIntersection2() {
    assertTrue(
        equalRectangles(
            new Rectangle(new Point(15, 15), 0, 0),
            new Rectangle(new Point(0, 0), 15, 15).intersection(new Rectangle(new Point(15, 15), 15, 15)).get()
        ));
  }

  @Test
  public void rectangleIntersection3() {
    assertFalse(
      new Rectangle(new Point(0, 0), 15, 15)
          .intersection(new Rectangle(new Point(16, 16), 15, 15)).isPresent());
  }

  @Test
  public void streamIntersectAll1() {
    assertTrue(
        equalRectangles(INCREASING_ENCLOSING.get(0),
            StreamAlgorithms.intersectAll(INCREASING_ENCLOSING.stream()).get())
    );
  }

  @Test
  public void streamIntersectAll2() {
    assertFalse(
        StreamAlgorithms.intersectAll(VARIOUS_RECTANGLES_TRANSLATED_AND_SCALED.stream())
            .isPresent());
  }
/*
  //===============================
  // 7. Tests for streams of cubes.
  //===============================

  @Test
  public void cubeSupplier() {
    final CubeSupplier cubeSupplier = new CubeSupplier();
    for (int i = 1; i <= 1000; i++) {
      assertEquals(i * i * i, (int) cubeSupplier.get());
    }
  }

  @Test
  public void cubeStream() {
    assertTrue(CubeSupplier.cubeStream().anyMatch(item -> item == 1000));
  }

  @Test(expected = NoSuchElementException.class)
  public void cubeStreamException() {
    // 999 is not a perfect cube, so we expect the cube stream to be generated until
    // the largest positive int value has been exceeded, in which case an exception
    // should be thrown.
    CubeSupplier.cubeStream().anyMatch(item -> item == 999);
  }

  @Test
  public void boundedCubeStream() {
    assertEquals((int) CubeSupplier.boundedCubeStream(0, 10)
          .reduce(0, Integer::sum), 3025);
  }

  @Test
  public void boundedCubeStreamNoException() {
    assertFalse(CubeSupplier.boundedCubeStream(0, 50).anyMatch(item -> item == 999));
  }

  @Test
  public void palindromes() {
    assertEquals(Arrays.asList(1, 8, 343, 1331, 1030301, 1367631),
          CubeSupplier.palindromicCubes(0, 1000).collect(Collectors.toList()));
  }

  //==============================
  // 8. Tests for string prefixes.
  //==============================

  private static final List<String> strings = Arrays.asList(
        "Java thinking",
        "Haskell programming",
        "Java programming",
        "Haskell breathing",
        "Java programming",
        "Java and Haskell: better together?",
        "Java programming",
        "Smalltalk programming",
        "C++ programming");

  @Test
  public void countStringsStartingWithPrefix() {
    assertEquals(0, StringPrefixes.countStringsStartingWithPrefix(
          Stream.empty(), "Hello"));
    assertEquals(5, StringPrefixes.countStringsStartingWithPrefix(
          strings.stream(), "Java"));
    assertEquals(2, StringPrefixes.countStringsStartingWithPrefix(
          strings.stream(), "Haskell"));
    assertEquals(0, StringPrefixes.countStringsStartingWithPrefix(
          strings.stream(), "C#"));
  }

  @Test
  public void emphasiseFirstStringStartingWithPrefix() {
    assertEquals("N/A", StringPrefixes.emphasiseFirstStringStartingWithPrefix(
          Stream.empty(), "Hello"));
    assertEquals("*Java* thinking", StringPrefixes.emphasiseFirstStringStartingWithPrefix(
          strings.stream(), "Java"));
    assertEquals("*Haskell* programming", StringPrefixes.emphasiseFirstStringStartingWithPrefix(
          strings.stream(), "Haskell"));
    assertEquals("N/A", StringPrefixes.emphasiseFirstStringStartingWithPrefix(
          strings.stream(), "C#"));
  }

  @Test
  public void distinctStringsStartingWithPrefix() {
    assertEquals(new ArrayList<>(), StringPrefixes.distinctStringsStartingWithPrefix(
          Stream.empty(), "Hello"));
    assertEquals(Arrays.asList(
            "Java thinking",
            "Java programming",
            "Java and Haskell: better together?"),
          StringPrefixes.distinctStringsStartingWithPrefix(strings.stream(), "Java"));
    assertEquals(Arrays.asList(
          "Haskell programming",
          "Haskell breathing"),
          StringPrefixes.distinctStringsStartingWithPrefix(strings.stream(), "Haskell"));
  }

  */

  // ============================
  // Additional tests for Point.
  // ============================

  // sees if the point has the same x axis even if the points aren't identical

  @Test
  public void pointIsLeftOfExtra() {
    assertTrue(new Point(10, 500).isLeftOf(new Point(20, 20)));
    assertFalse(new Point(10, 200).isLeftOf(new Point(10, 11)));
  }

  // same as pointIsLeftOfExtra

  @Test
  public void pointIsRightOfExtra() {
    assertTrue(new Point(10, 40).isRightOf(new Point(0, 15)));
    assertFalse(new Point(10, 200).isRightOf(new Point(12, 11)));
  }

  // tests to see if y axis is identical

  @Test
  public void pointIsAboveExtra() {
    assertTrue(new Point(8, 3).isAbove(new Point(5, 4)));
    assertFalse(new Point(10, 0).isAbove(new Point(0, 0)));
  }

// Both 2 following test assert the negative coordinate problem

  @Test(expected = AssertionError.class)
  public void NegativeX() {
    new Point(0, 0).setX(-3);
  }

  @Test(expected = AssertionError.class)
  public void NegativeY() {
    new Point(0, 0).setY(-3);
  }

  // ================================
  // Additional tests for Rectangle.
  // ================================


  // checks if a single point counts as intersection
  @Test
  public void rectangleIntersect4() {
    assertTrue(
        new Rectangle(new Point(0, 0), 3, 3).intersects(new Rectangle(new Point(3, 3), 10, 10)));
  }

  // checks negative value for height
  @Test(expected = AssertionError.class)
  public void getNegativeHeight() {
    new Rectangle(new Point(0,0), 10, -5);
  }

  // checks negative value for width
  @Test(expected = AssertionError.class)
  public void getNegativeWidth() {
    new Rectangle(new Point(0,0), -5, -10);
  }

  // checks edge cases for area
  @Test
  public void rectangleAreaExtra() {
    assertEquals(0, new Rectangle(0, 10).area());
    assertEquals(0, new Rectangle(new Point(), new Point(6, 0)).area());
  }



  // =====================================
  // Additional tests for ListAlgorithms.
  // =====================================

  private static final List<Rectangle> MY_RECTANGLES_TRANS = Arrays.asList(
      new Rectangle(new Point(0, 0), 100, 100));

  private static final List<Rectangle> MY_RECTANGLES = Arrays.asList(
      new Rectangle(new Point(10, 10), 100, 100));

   // test negative translation

  @Test
  public void listTranslateExtra() {
    assertTrue(equalRectangleLists(
        MY_RECTANGLES_TRANS,
        ListAlgorithms.translate(MY_RECTANGLES, new Point(-10, -10))));
  }

  private static final List<Rectangle> MY_RECTANGLES_SCALED = Arrays.asList(
      new Rectangle(new Point(10, 10), 0, 0));


  // test if 1 would affect anything
  @Test
  public void listScaleExtra() {
    assertTrue(equalRectangleLists(
        MY_RECTANGLES, ListAlgorithms.scale(MY_RECTANGLES, 1)));
  }

  //tests 0, found out that assertion for Height and Width were wrong, not accepting 0
    @Test
    public void listScaleZeroExtra() {
      assertTrue(equalRectangleLists(
          MY_RECTANGLES_SCALED, ListAlgorithms.scale(MY_RECTANGLES, 0)));
    }

    //can not scale with negative values, since Height and Width are always positive
  @Test(expected = AssertionError.class)
  public void listScaleMinusExtra() {
    assertTrue(equalRectangleLists(
        MY_RECTANGLES_SCALED, ListAlgorithms.scale(MY_RECTANGLES, -1)));
  }


  // =======================================
  // Additional tests for StreamAlgorithms.
  // =======================================

  //as stated in the spec, the following tests are re-implementations
  @Test
  public void streamTranslateExtra() {
    assertTrue(equalRectangleLists(
        MY_RECTANGLES_TRANS, StreamAlgorithms
            .translate(MY_RECTANGLES.stream(), new Point(-10, -10)).collect(toList())));
  }

  @Test
  public void streamScaleZeroExtra() {
    assertTrue(equalRectangleLists(
        MY_RECTANGLES_SCALED,
        StreamAlgorithms.scale(MY_RECTANGLES.stream(), 0).collect(toList())));
  }

  @Test
  public void streamScaleExtra() {
    assertTrue(equalRectangleLists(
        MY_RECTANGLES,
        StreamAlgorithms.scale(MY_RECTANGLES.stream(), 1).collect(toList())));
  }

  @Test(expected = AssertionError.class)
  public void streamScaleMinusExtra() {
    assertTrue(equalRectangleLists(
        MY_RECTANGLES,
        StreamAlgorithms.scale(MY_RECTANGLES.stream(), -1).collect(toList())));
  }

  // ==============================================
  // Additional tests for intersecting rectangles.
  // ==============================================

  //see if two separate rectangles intersect
  @Test
  public void rectangleIntersectionEx() {
    assertTrue(
        Optional.empty().equals(
            new Rectangle(new Point(0, 0), 15, 15).intersection(new Rectangle(new Point(100, 100), 15, 15)))
        );
  }

  //checks if smaller rectangle inside a bigger one returns the small rectangle
  @Test
  public void rectangleIntersectionExtra() {
    assertTrue(
        equalRectangles(
            new Rectangle(new Point(10, 10), 5, 5),
            new Rectangle(new Point(10, 10), 5, 5).intersection(new Rectangle(new Point(10, 10), 100, 100)).get()
        ));
  }

  //checks validity
  @Test
  public void intersectAllExtra() {
    assertFalse(
        equalRectangles(INCREASING_ENCLOSING.get(3),
            StreamAlgorithms.intersectAll(INCREASING_ENCLOSING.stream()).get())
    );
  }




}
