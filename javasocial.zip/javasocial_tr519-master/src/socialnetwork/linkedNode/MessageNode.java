package socialnetwork.linkedNode;

import java.awt.HeadlessException;
import socialnetwork.domain.Message;

public class MessageNode {

  private Message message;
  private MessageNode lastNode;
  private MessageNode nextNode;

  public MessageNode(MessageNode lastNode, Message message, MessageNode nextNode) {
    this.lastNode = lastNode;
    this.message = message;
    this.nextNode = nextNode;
  }

  public MessageNode addNext(Message message) {
    MessageNode tempNode = new MessageNode(this, message, nextNode);
    nextNode = tempNode;
    return tempNode;
  }

  public MessageNode getPreviousNode() {
    return lastNode;
  }

  public Message getMessage() {
    return message;
  }

  public MessageNode getNextNode() {
    return nextNode;
  }

  public void setNext(MessageNode nodeSet) {
    nextNode = nodeSet;
  }

  public void deleteNode() {
    getPreviousNode().nextNode = nextNode;
    getNextNode().lastNode = lastNode;
  }
}
