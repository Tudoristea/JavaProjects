package socialnetwork.linkedNode;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import socialnetwork.domain.Task;

public class FineTaskNode {

  private Task task;
  private FineTaskNode lastNode;
  private FineTaskNode nextNode;

  private Lock lock = new ReentrantLock();

  public void lock() {
    lock.lock();
  }

  public void unlock() {
    lock.unlock();
  }

  public FineTaskNode(FineTaskNode lastNode, Task task, FineTaskNode nextNode) {
    this.lastNode = lastNode;
    this.task = task;
    this.nextNode = nextNode;
  }

  public FineTaskNode add(Task taskParsed) {
    FineTaskNode newTaskNode = new FineTaskNode(this, taskParsed, this.nextNode);
    nextNode = newTaskNode;
    return newTaskNode;
  }

  public void setNext(FineTaskNode nodeSet) {
    nextNode = nodeSet;
  }

  public FineTaskNode getNextNode() {
    return nextNode;
  }

  public FineTaskNode getPreviousNode() {
    return lastNode;
  }

  public Task getTask() {
    return task;
  }

  public void delete() {
    lastNode.nextNode = nextNode;
    nextNode.lastNode = lastNode;
  }
}
