package socialnetwork.linkedNode;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import socialnetwork.domain.Message;

public class FineMsgNode {

  private Message message;
  private FineMsgNode lastNode;
  private FineMsgNode nextNode;

  private Lock lock = new ReentrantLock();

  public void lock() {
    lock.lock();
  }

  public void unlock() {
    lock.unlock();
  }

  public FineMsgNode(FineMsgNode lastNode, Message message, FineMsgNode nextNode) {
    this.lastNode = lastNode;
    this.message = message;
    this.nextNode = nextNode;
  }

  public void setNext(FineMsgNode nodeSet) {
    nextNode = nodeSet;
  }

  public FineMsgNode getNextNode() {
    return nextNode;
  }

  public Message getMessage() {
    return message;
  }

  public FineMsgNode addNext(Message message) {
    FineMsgNode tempNode = new FineMsgNode(this, message, nextNode);
    nextNode = tempNode;
    return tempNode;
  }

  public FineMsgNode getPreviousNode() {
    return lastNode;
  }

  public void deleteNode() {
    getPreviousNode().nextNode = nextNode;
    getNextNode().lastNode = lastNode;
  }
}
