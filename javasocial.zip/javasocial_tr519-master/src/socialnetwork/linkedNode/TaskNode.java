package socialnetwork.linkedNode;

import socialnetwork.domain.Task;

public class TaskNode {

  private Task task;
  private TaskNode lastNode;
  private TaskNode nextNode;

  public TaskNode(TaskNode lastNode, Task task, TaskNode nextNode) {
    this.lastNode = lastNode;
    this.task = task;
    this.nextNode = nextNode;
  }

  public TaskNode add(Task taskParsed) {
    TaskNode newTaskNode = new TaskNode(this, taskParsed, this.nextNode);
    nextNode = newTaskNode;
    return newTaskNode;
  }

  public void setNext(TaskNode nodeSet) {
    nextNode = nodeSet;
  }

  public TaskNode getNextNode() {
    return nextNode;
  }

  public TaskNode getPreviousNode() {
    return lastNode;
  }

  public Task getTask() {
    return task;
  }

  public void delete() {
    lastNode.nextNode = nextNode;
    nextNode.lastNode = lastNode;
  }
}
