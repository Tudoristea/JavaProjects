package socialnetwork;

import java.util.Optional;
import socialnetwork.domain.Backlog;
import socialnetwork.domain.Task;
import socialnetwork.linkedNode.TaskNode;

public class CoarseSyncBacklog implements Backlog {

  private TaskNode firstTask;
  private TaskNode lastTask;

  private int size;

  public CoarseSyncBacklog() {
    size = 0;
    firstTask = new TaskNode(null, null, null);
    lastTask = new TaskNode(firstTask, null, null);
    firstTask.setNext(lastTask);
    size = 0;
  }

  @Override
  public synchronized boolean add(Task task) {
    TaskNode currentNode = lastTask.getPreviousNode();
    currentNode = currentNode.add(task);
    size++;
    return true;
  }

  @Override
  public synchronized Optional<Task> getNextTaskToProcess() {
    if (size == 0) {
      return Optional.empty();
    } else {
      size--;
      TaskNode returningNode = firstTask.getNextNode();
      firstTask.getNextNode().delete();
      return Optional.of(returningNode.getTask());
    }
  }

  @Override
  public synchronized int numberOfTasksInTheBacklog() {
    return size;
  }
}
