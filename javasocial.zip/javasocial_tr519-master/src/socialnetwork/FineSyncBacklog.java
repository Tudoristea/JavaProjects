package socialnetwork;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import socialnetwork.domain.Backlog;
import socialnetwork.domain.Task;
import socialnetwork.linkedNode.FineTaskNode;

public class FineSyncBacklog implements Backlog {

  private FineTaskNode firstTask;
  private FineTaskNode lastTask;

  private AtomicInteger size = new AtomicInteger();

  private Lock lock = new ReentrantLock();

  public FineSyncBacklog() {
    size.set(0);
    firstTask = new FineTaskNode(null, null, null);
    lastTask = new FineTaskNode(firstTask, null, null);
    firstTask.setNext(lastTask);
  }

  @Override
  public synchronized boolean add(Task task) {
    FineTaskNode currentNode = lastTask.getPreviousNode();
    currentNode = currentNode.add(task);
    size.getAndIncrement();
    return true;
  }

  @Override
  public Optional<Task> getNextTaskToProcess() {
    if (size.get() == 0) {
      return Optional.empty();
    } else {
      size.getAndDecrement();
      try {
        lock.lock();
        FineTaskNode returningNode = firstTask.getNextNode();
        firstTask.getNextNode().delete();
        return Optional.of(returningNode.getTask());
      } finally {
        lock.unlock();
      }
    }
  }

  @Override
  public int numberOfTasksInTheBacklog() {
    return size.get();
  }
}
