package socialnetwork;

public class Main {

  public static void main(String[] args) {
    // Implement logic here following the steps described in the specs

  }
}
