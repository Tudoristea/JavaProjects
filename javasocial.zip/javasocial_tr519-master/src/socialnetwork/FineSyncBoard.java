package socialnetwork;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import socialnetwork.domain.Board;
import socialnetwork.domain.Message;
import socialnetwork.linkedNode.FineMsgNode;

public class FineSyncBoard implements Board {

  private Lock lock = new ReentrantLock();
  private FineMsgNode firstMessage;
  private FineMsgNode lastMessage;
  private int size;

  public FineSyncBoard() {
    size = 0;
    firstMessage = new FineMsgNode(null, null, null);
    lastMessage = new FineMsgNode(firstMessage, null, null);
    firstMessage.setNext(lastMessage);
  }

  @Override
  public boolean addMessage(Message message) {
    FineMsgNode pred, curr;
    pred = firstMessage;
    pred.lock();
    curr = firstMessage.getNextNode();
    while (curr != null) {
      if (curr == lastMessage
          || curr.getNextNode().getMessage().getMessageId() > message.getMessageId()) {
        pred.addNext(message);
        size++;
        pred.unlock();
        curr.unlock();
        return true;
      }
      pred.unlock();
      pred = curr;
      curr = curr.getNextNode();
      curr.lock();
    }
    size++;
    pred.unlock();
    return false;
  }

  @Override
  public boolean deleteMessage(Message message) {
    FineMsgNode pred, curr;
    pred = firstMessage;
    pred.lock();
    curr = firstMessage.getNextNode();
    while (curr != null) {
      if (curr == lastMessage || curr.getNextNode().getMessage() == message) {
        curr.deleteNode();
        size--;
        pred.unlock();
        curr.unlock();
        return true;
      }
      pred.unlock();
      pred = curr;
      curr = curr.getNextNode();
      curr.lock();
    }
    size++;
    pred.unlock();
    return false;
  }

  @Override
  public synchronized int size() {
    return size;
  }

  @Override
  public List<Message> getBoardSnapshot() {
    List<Message> msgList = new LinkedList<>();
    if (size != 0) {
      try {
        lock.lock();
        FineMsgNode pointer = firstMessage.getNextNode(); // so it does not include HEAD
        while (pointer != lastMessage) {
          msgList.add(pointer.getMessage());
          pointer = pointer.getNextNode();
        }
      } finally {
        lock.unlock();
      }
    }
    return msgList;
  }
}
