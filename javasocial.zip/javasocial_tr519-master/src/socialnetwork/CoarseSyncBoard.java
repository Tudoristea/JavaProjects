package socialnetwork;

import java.util.LinkedList;
import java.util.List;
import socialnetwork.domain.Board;
import socialnetwork.domain.Message;
import socialnetwork.linkedNode.MessageNode;

public class CoarseSyncBoard implements Board {

  private int size;
  private MessageNode firstMessage;
  private MessageNode lastMessage;

  public CoarseSyncBoard() {
    firstMessage = new MessageNode(null, null, null);
    lastMessage = new MessageNode(firstMessage, null, null);
    firstMessage.setNext(lastMessage);
    size = 0;
  }

  @Override
  public synchronized boolean addMessage(Message message) {
    List<Message> msgList = getBoardSnapshot();
    if (msgList.contains(message)) {
      return false;
    }
    MessageNode currentMessage = firstMessage;
    while (currentMessage != lastMessage) {
      if (currentMessage.getNextNode() == lastMessage
          || currentMessage.getNextNode().getMessage().getMessageId() > message.getMessageId()) {
        currentMessage = currentMessage.addNext(message);
        size++;
      }
      currentMessage = currentMessage.getNextNode();
    }
    return false;
  }

  @Override
  public synchronized boolean deleteMessage(Message message) {
    boolean wasDeleted = false;
    MessageNode pointer = firstMessage.getNextNode(); // so we don't start with the head
    while (pointer != lastMessage) {
      if (pointer.getMessage() == message) {
        pointer.deleteNode();
        wasDeleted = true;
      }
      pointer = pointer.getNextNode();
    }
    return wasDeleted;
  }

  @Override
  public synchronized int size() {
    return size;
  }

  @Override
  public synchronized List<Message> getBoardSnapshot() {
    List<Message> msgList = new LinkedList<>();
    if (size != 0) {
      MessageNode pointer = firstMessage.getNextNode(); // so it does not include HEAD
      while (pointer != lastMessage) {
        msgList.add(pointer.getMessage());
        pointer = pointer.getNextNode();
      }
    }
    return msgList;
  }
}
