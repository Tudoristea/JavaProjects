package picture;

import java.util.ArrayList;
import java.util.List;

public class Main {

  public static Picture invert(String locationString) {
    Picture picture = Utils.loadPicture(locationString);
    for (int i = 0; i < picture.getWidth(); i++) {
      for (int j = 0; j < picture.getHeight(); j++) {
        Color newRGB = new Color(0, 0, 0);
        newRGB.setRed(255 - picture.getPixel(i, j).getRed());
        newRGB.setGreen(255 - picture.getPixel(i, j).getGreen());
        newRGB.setBlue(255 - picture.getPixel(i, j).getBlue());
        picture.setPixel(i, j, newRGB);
      }
    }
    return picture;
  }

  public static Picture grayscale(String locationString) {
    Picture picture = Utils.loadPicture(locationString);
    for (int i = 0; i < picture.getWidth(); i++) {
      for (int j = 0; j < picture.getHeight(); j++) {
        int red = picture.getPixel(i, j).getRed();
        int green = picture.getPixel(i, j).getGreen();
        int blue = picture.getPixel(i, j).getBlue();
        int avg = (red + green + blue) / 3;
        Color newRGB = new Color(avg, avg, avg);
        picture.setPixel(i, j, newRGB);
      }
    }
    return picture;
  }

  public static Picture rotate(String locationString, int ang) {
    Picture picture = Utils.loadPicture(locationString);
    Picture newPicture = Utils.createPicture(1, 1);
    switch (ang) {
      case 90:
        newPicture = Utils.createPicture(picture.getHeight(), picture.getWidth());
        for (int i = 0; i < picture.getWidth(); i++) {
          for (int j = 0; j < picture.getHeight(); j++) {
            newPicture.setPixel(picture.getHeight() - 1 - j, i, picture.getPixel(i, j));
          }
        }
        break;
      case 180:
        newPicture = Utils.createPicture(picture.getWidth(), picture.getHeight());
        for (int i = 0; i < picture.getWidth(); i++) {
          for (int j = 0; j < picture.getHeight(); j++) {
            newPicture.setPixel(
                picture.getWidth() - i - 1, picture.getHeight() - j - 1, picture.getPixel(i, j));
          } // look into this
        }
        break;
      case 270:
        newPicture = Utils.createPicture(picture.getHeight(), picture.getWidth());
        for (int i = 0; i < picture.getWidth(); i++) {
          for (int j = 0; j < picture.getHeight(); j++) {
            newPicture.setPixel(j,picture.getWidth() - i - 1, picture.getPixel(i, j));
          }
        }
        break;
      default:
        System.out.println("Invalid angle");
    }
    return newPicture;
  }

  public static Picture flip(String locationString, char flp) {
    flp = Character.toUpperCase(flp);
    Picture picture = Utils.loadPicture(locationString);
    Picture newPicture = Utils.createPicture(picture.getWidth(), picture.getHeight());
    if (flp == 'H') {
      for (int i = 0; i < picture.getWidth(); i++) {
        for (int j = 0; j < picture.getHeight(); j++) {
          newPicture.setPixel(picture.getWidth() - i - 1, j, picture.getPixel(i, j));
        }
      }
    } else if (flp == 'V') { // flip V is also flipH of rotate 180
      for (int i = 0; i < picture.getWidth(); i++) {
        for (int j = 0; j < picture.getHeight(); j++) {
          newPicture.setPixel(i, picture.getHeight() - j - 1, picture.getPixel(i, j));
        }
      }
    } else {
      System.out.println("Invalid flip value");
    }
    return newPicture;
  }

  public static Picture blend(List<Picture> list) {
    int w = -1;
    int h = -1;
    for (Picture pic : list) {
      if (w < 0 || w >= pic.getWidth()) {
        w = pic.getWidth();
      }
      if (h < 0 || h >= pic.getHeight()) {
        h = pic.getHeight();
      }
    }
    Picture newPicture = Utils.createPicture(w, h);
      for (int i = 0; i < newPicture.getWidth(); i++) {
        for (int j = 0; j < newPicture.getHeight(); j++) {
          Color newRGB = new Color (0,0,0);
          int numberOfPics = 0;
          for (Picture pic : list) {
            numberOfPics++;
            newRGB.setRed(newRGB.getRed() + pic.getPixel(i, j).getRed());
            newRGB.setBlue(newRGB.getBlue() + pic.getPixel(i, j).getBlue());
            newRGB.setGreen(newRGB.getGreen() + pic.getPixel(i, j).getGreen());
            }
          newRGB.setRed(newRGB.getRed() / numberOfPics);
          newRGB.setBlue(newRGB.getBlue() / numberOfPics);
          newRGB.setGreen(newRGB.getGreen() / numberOfPics);
          newPicture.setPixel(i, j, newRGB);
        }
      }
    return newPicture;
  }

  public static Picture blur(String locationString) {
    Picture picture = Utils.loadPicture(locationString);
    Picture newPicture = Utils.createPicture(picture.getWidth(), picture.getHeight());
    for (int i = 0; i < picture.getWidth(); i++) {
      newPicture.setPixel(i, 0, picture.getPixel(i, 0));
      newPicture.setPixel(i, picture.getHeight() - 1, picture.getPixel(i, picture.getHeight() - 1));
    }
    for (int i = 0; i < picture.getHeight(); i++) {
      newPicture.setPixel(0, i, picture.getPixel(0, i));
      newPicture.setPixel(picture.getWidth() - 1, i, picture.getPixel(picture.getWidth() - 1, i));
      }
    for (int i = 1; i < picture.getWidth() - 1; i++) {
      for (int j = 1; j < picture.getHeight() - 1; j++) {
        Color newRGB = new Color(0, 0, 0);
        for (int iP = i - 1; iP <= i + 1; iP++) {
          for (int jP = j - 1; jP <= j + 1; jP++) {
            newRGB.setRed(newRGB.getRed() + picture.getPixel(iP, jP).getRed());
            newRGB.setBlue(newRGB.getBlue() + picture.getPixel(iP, jP).getBlue());
            newRGB.setGreen(newRGB.getGreen() + picture.getPixel(iP, jP).getGreen());
          }
        }
        newRGB.setRed(newRGB.getRed() / 9);
        newRGB.setBlue(newRGB.getBlue() / 9);
        newRGB.setGreen(newRGB.getGreen() / 9);
        newPicture.setPixel(i, j, newRGB);
      }
    }
    return newPicture;
  }

  public static void main(String[] args) {
    switch(args[0]) {
      case "rotate":
        Utils.savePicture(Main.rotate(args[2], Integer.parseInt(args[1])), args[3]);
        return;
      case "invert":
        Utils.savePicture(Main.invert(args[1]), args[2]);
        return;
      case "grayscale":
        Utils.savePicture(Main.grayscale(args[1]), args[2]);
        return;
      case "flip":
        Utils.savePicture(Main.flip(args[2], args[1].charAt(0)), args[3]);
        return;
      case "blur":
        Utils.savePicture(Main.blur(args[1]), args[2]);
        return;
      case "blend":
        List<Picture> list = new ArrayList<>();
        for (int i = 1; i < args.length - 1; i++) {
          Picture pic = Utils.loadPicture(args[i]);
          list.add(pic);
        }
        Utils.savePicture(Main.blend(list), args[args.length - 1]);
        return;
    }
  }
}
