public class Page {

  private char[][] grid;
  int size;

  public Page(int size) {
    this.size = size;
    assert size >= 0 : "Input a positive size";
    this.grid = new char[size][size];
    clear();
  }

  public int getsize() {
    return this.size;
  }

  private void clear() {
    for (int i = 0; i < grid.length; i++) {
      for (int j = 0; j < grid.length; j++) {
        grid[i][j] = ' ';
      }
    }
  }

  public void draw(int i, int j, Pen pen) {
    grid[i][j] = pen.getStroke();
  }

  public String toString() {
    StringBuffer stringBuf = new StringBuffer();
    for (int i = 0; i < grid.length; i++) {
      for (int j = 0; j < grid.length; j++) {
        stringBuf.append(grid[j][i]);
      }
      stringBuf.append('\n');
    }
    return stringBuf.toString();
  }
}
