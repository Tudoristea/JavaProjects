public class Turtle {

  private Page page;
  private Pen pen;
  int deltaI = 0;
  int deltaJ = 0;

  public Turtle(Page page, Pen pen) {
    this.page = page;
    this.pen = pen;
  }

  public void setPen(Pen pen) {
    this.pen = pen;
  }

  public void penUp() {
    pen.penDown = false;
  }

  public void penDown() {
    pen.penDown = true;
  }

  public boolean isPenDown() {
    return pen.penDown;
  }

  public void move(Direction direction, int distance) {
    assert distance >= 0 : "Input a positive value";
    if (isPenDown()) {
      page.draw(deltaI, deltaJ, pen);
    }
    while (distance > 0) {
      if (direction == Direction.NORTH) {
        deltaJ = (deltaJ + 1) % (page.getsize() - 1);
      } else if (direction == Direction.EAST) {
        deltaI = (deltaI + 1) % (page.getsize() - 1);
      } else if (direction == Direction.SOUTH) {
        deltaJ = (deltaJ - 1) % (page.getsize() - 1);
      } else if (direction == Direction.WEST) {
        deltaI = (deltaI - 1) % (page.getsize() - 1);
      } else if (direction == Direction.NORTHEAST) {
        deltaJ = (deltaJ + 1) % (page.getsize() - 1);
        deltaI = (deltaI + 1) % (page.getsize() - 1);
      } else if (direction == Direction.SOUTHEAST) {
        deltaJ = (deltaJ - 1) % (page.getsize() - 1);
        deltaI = (deltaI + 1) % (page.getsize() - 1);
      } else if (direction == Direction.SOUTHWEST) {
        deltaJ = (deltaJ - 1) % (page.getsize() - 1);
        deltaI = (deltaI - 1) % (page.getsize() - 1);
      } else if (direction == Direction.NORTHWEST){
        deltaJ = (deltaJ + 1) % (page.getsize() - 1);
        deltaI = (deltaI - 1) % (page.getsize() - 1);
      }


      if (deltaI < 0) {
        deltaI = 0;
    }
      if (deltaJ < 0) {
        deltaJ = 0;
      }

      if (isPenDown()) {
        page.draw(deltaI, deltaJ, pen);
      }

      distance--;
    }
  }

  private void makeMark() {}

  // private void move(int deltaI, int deltaJ, int distance) {

  // }
}
