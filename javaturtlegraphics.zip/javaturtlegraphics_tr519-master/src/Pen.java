public class Pen {

  boolean penDown;
  char stroke;

  public Pen(char stroke) {
    assert (stroke != ' ' && stroke != '\n' && stroke != '\t')  : "Input a non-space char";
      this.stroke = stroke;
      penDown = false;
  }

  public char getStroke() {
    return stroke;
  }

}

