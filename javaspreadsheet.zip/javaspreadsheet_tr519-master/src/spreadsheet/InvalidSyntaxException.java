package spreadsheet;

public class InvalidSyntaxException extends Exception {
  public InvalidSyntaxException(String message) {
    super(message);
  }
}
