package spreadsheet;

import common.api.CellLocation;
import common.api.EvaluationContext;
import common.api.Expression;
import java.util.Set;

public class CellReferences implements Expression {

  private CellLocation cellLoc;

  public CellReferences(CellLocation cellLoc) {
    this.cellLoc = cellLoc;
  }

  public double evaluate(EvaluationContext context) {
    return context.getCellValue(cellLoc);
  }

  public void findCellReferences(Set<CellLocation> dependencies) {
    dependencies.add(cellLoc);
  }

  @Override
  public String toString() {
    return cellLoc.toString();
  }
}
