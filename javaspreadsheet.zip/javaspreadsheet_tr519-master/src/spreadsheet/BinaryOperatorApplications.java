package spreadsheet;

import common.api.CellLocation;
import common.api.EvaluationContext;
import common.api.Expression;
import common.lexer.Token.Kind;
import java.util.Set;
import java.util.function.BinaryOperator;

public class BinaryOperatorApplications implements Expression {

  private Expression expr1;
  private Expression expr2;
  private Bin bin;

  public BinaryOperatorApplications (Expression expr1, Bin bin, Expression expr2) {
    this.expr1 = expr1;
    this.expr2 = expr2;
    this.bin = bin;
  }

  public double evaluate(EvaluationContext context) {
    // TODO switch on kind or my own class
    return (double) bin.apply(expr1.evaluate(context), expr2.evaluate(context));
  }

  public void findCellReferences(Set<CellLocation> dependencies){}

  @Override
  public String toString() {
    return "(" + expr1.toString() + " " + bin.toString() + " " + expr2.toString() + ")";
  }
}
