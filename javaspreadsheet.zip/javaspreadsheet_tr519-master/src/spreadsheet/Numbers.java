package spreadsheet;

import common.api.CellLocation;
import common.api.EvaluationContext;
import common.api.Expression;
import java.util.Set;

public class Numbers implements Expression {

  private double num;

  public Numbers(double num) {
    this.num = num;
  }

  public double evaluate(EvaluationContext context) {
    return 0;
  }

  public void findCellReferences(Set<CellLocation> dependencies){}

  @Override
  public String toString() {
    return Double.toString(num);
  }
}
