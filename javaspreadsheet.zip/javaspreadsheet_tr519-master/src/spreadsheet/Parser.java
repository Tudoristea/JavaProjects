package spreadsheet;

import common.api.Expression;
import common.lexer.InvalidTokenException;
import common.lexer.Lexer;
import common.lexer.Token;
import common.lexer.Token.Kind;
import java.util.Stack;

public class Parser {
  /**
   * Parse a string into an Expression.
   *
   * <p>DO NOT CHANGE THE SIGNATURE. The test suite depends on this.
   */
  static Expression parse(String input) {
    Lexer lexer = new Lexer(input);
    Stack<Token> operator = new Stack<>();
    Stack<Expression> operand = new Stack<>();
    while (true) {
      try {
        Token token = lexer.nextToken();
        switch (token.kind) {
          case NUMBER:
            operand.push(new Numbers(token.numberValue));
            break;
          case CELL_LOCATION:
            operand.push(new CellReferences(token.cellLocationValue));
            break;
          case PLUS:
             if (operator.peek().equals(Kind.CARET) || operator.peek().equals(Kind.STAR)
                 || operator.peek().equals(Kind.SLASH) || operator.isEmpty()) {
               operator.push(token); }
             else {
               operand.push(new BinaryOperatorApplications(operand.pop(), Bin.PLUS , operand.pop()));}
            break;
          case MINUS:
            if (operator.isEmpty())
              operator.push(token);
            break;
          case STAR:
            if (operator.empty() || operator.peek().equals(Kind.CARET))
              operator.push(token);
            else {
            }
            break;
          case SLASH:
            if (operator.empty() || operator.peek().equals(Kind.CARET))
              operator.push(token);
            else {
            }
            break;
          case CARET:
            if (operator.isEmpty())
              operator.push(token);
        }
      } catch (InvalidTokenException exception) {
        break;
      }
    }
  }
}

enum Bin {
  PLUS()// TODO precedence and assoc
}