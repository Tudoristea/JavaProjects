package common.api;

public interface EvaluationContext {
  double getCellValue(CellLocation location);
}
