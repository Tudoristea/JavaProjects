package simulation;

public class ScheduledEvent<S> implements Comparable<ScheduledEvent> {

  private Event event;
  private double time;

  ScheduledEvent(Event event, Double time) {
    this.event = event;
    this.time = time;
  }

  @Override
  public int compareTo(ScheduledEvent schEve) {
    return Double.compare(time, schEve.time);
  }

  Event getEvent() {
    return event;
  }

  Double getTime() {
    return time;
  }
}
