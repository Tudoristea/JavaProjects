package simulation;
import java.util.ArrayDeque;
import java.util.PriorityQueue;
import java.util.Queue;


public abstract class Simulation<S> {

  private double currentVirtualTime;
  private Queue<ScheduledEvent> diary = new PriorityQueue<>();

  protected abstract boolean stop();

  public void schedule(Event e, double offset) {
    diary.add(new ScheduledEvent(e,currentVirtualTime + offset));
  }

  public double getCurrentTime() {
    return currentVirtualTime;
  }

  protected abstract S getState();


  public void simulate() {
    while (!diary.isEmpty() && !stop()) {
      ScheduledEvent svhEve = diary.poll();
      currentVirtualTime = svhEve.getTime();
      svhEve.getEvent().invoke(getState());
    }
  }
}
