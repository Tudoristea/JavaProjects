package ticks;

import simulation.Simulation;

public class Ticks extends Simulation<Ticks> {

  private double time;

  public Ticks(double time) {
    this.time = time;
  }

  public boolean stop() {
    return getCurrentTime() >= time - 1;
  }

  protected Ticks getState() {
  return this;
  }

  public static void main(String[] args) {
    Ticks tick = new Ticks(Double.parseDouble(args[0]));
    tick.schedule(new TicksEvent(),1);
    tick.simulate();
  }
}
