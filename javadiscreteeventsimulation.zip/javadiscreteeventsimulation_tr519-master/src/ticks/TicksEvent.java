package ticks;

import simulation.Event;
import simulation.Simulation;

public class TicksEvent implements Event<Ticks> {

  @Override
  public void invoke(Ticks simulation) {
    System.out.println("Tick at: " + simulation.getCurrentTime());
    simulation.schedule(new TicksEvent(), 1);
  }


}
