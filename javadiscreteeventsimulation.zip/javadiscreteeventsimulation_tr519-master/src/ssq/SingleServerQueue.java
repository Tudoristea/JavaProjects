package ssq;

import java.util.Random;
import simulation.Simulation;

public class SingleServerQueue extends Simulation<SingleServerQueue> {

  private double time;
  private int queueLength;
  private double serviceTime;
  private Random interArrivalTime;
  private double meanTime = 0;
  private double pastTime;

  public SingleServerQueue(Long seed, double serviceTime, double time) {
    this.time = time;
    this.serviceTime = serviceTime;
    queueLength = 0;
    interArrivalTime = new Random(seed);
    pastTime = 0;
  }

  double getInterArrival() {
    return interArrivalTime.nextDouble();
  }

  void increment() {
    meanTime += getQueueLength() * (getCurrentTime() - pastTime);
    pastTime = getCurrentTime();
    queueLength++;
  }

  void decrement() {
    meanTime += getQueueLength() * (getCurrentTime() - pastTime);
    pastTime = getCurrentTime();
    queueLength--;
  }

  double getServiceTime() {
    return serviceTime;
  }

  int getQueueLength() {
    return queueLength;
  }

  public boolean stop() {
    return getCurrentTime() >= time;
  }

  protected SingleServerQueue getState() {
    return this;
  }

  private double getMeanQueLength() {
    return meanTime / getCurrentTime();
  }

  public static void main(String[] args) {
    SingleServerQueue queue =
        new SingleServerQueue(Long.parseLong(args[0]), 0.25, Double.parseDouble(args[1]));
    queue.schedule(new Arrival(), queue.getInterArrival());
    queue.simulate();
    System.out.println(
        "SIMULATION COMPLETE - the mean queue length was " + queue.getMeanQueLength());
  }
}
