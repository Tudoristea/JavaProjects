package ssq;

import simulation.Event;

public class Arrival implements Event<SingleServerQueue> {

  public void invoke(SingleServerQueue sim) {
    if (sim.getQueueLength() == 0) {
      sim.schedule(new Departure(), sim.getServiceTime());
    }
    sim.increment();
    sim.schedule(new Arrival(), sim.getInterArrival());
    if (!sim.stop())
      System.out.println(
          "Arrival at: " + sim.getCurrentTime() + ", new population = " + sim.getQueueLength());
  }
}
