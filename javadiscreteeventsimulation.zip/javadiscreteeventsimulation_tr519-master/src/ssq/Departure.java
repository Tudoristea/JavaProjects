package ssq;

import simulation.Event;

public class Departure implements Event<SingleServerQueue> {

  public void invoke(SingleServerQueue sim) {
    sim.decrement();
    if (sim.getQueueLength() != 0) {
      sim.schedule(new Departure(), sim.getServiceTime());
    }
    if (!sim.stop()) {
      System.out.println(
          "Departure at: " + sim.getCurrentTime() + ", new population = " + sim.getQueueLength());
    }
  }
}
