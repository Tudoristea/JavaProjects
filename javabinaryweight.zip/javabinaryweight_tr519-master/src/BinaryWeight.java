public class BinaryWeight {

  // My username is tr519 and I spent 3 hours completing this lab

  private String weight;


  public BinaryWeight(String s) {
    if (isBinaryString(s)) {
      weight = s;
    } else {
      weight = "0";
    }
  }

  public BinaryWeight(int n) {
    if (n > 0) {
      weight = toBinary(n);
    } else {
      weight = "0";
    }

  }

  private boolean isBinaryString(String s) {
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c != '0' && c != '1') {
        return false;
      }
    }
    return true;
  }

  public String asString() {
    return weight;
  }

  private String toBinary(int n) {
    return Integer.toBinaryString(n) ;
  }

  public int asDecimal() {
    int newCons = 0;
    int k = this.asString().length() - 1;
    if (isBinaryString(weight)) {
      for (int i = 0; i < weight.length(); i++) {
        if (weight.charAt(i) == '1') {
          newCons = (int) (newCons + Math.pow (2 , (k - i)));
        }
      }
    }
    return newCons;
  }

  /*
  public String toString() {
    System.out.println("The weights that you need to represent (" + Integer.toString(toInt(weight)) + ") are:");
    int k = this.asString().length() - 1;
    for (int i = weight.length() - 1; i >= 0; i--) {
      if (weight.charAt((i)) == '1')
        System.out.println("1 " + "x " + ( (int) (Math.pow(2 , (k - i)))) + " unit");
    }
    return "";
  }
  */

  public String toString() {
    String newWeight = "The weights that you need to represent (" + Integer.toString(toInt(weight)) + ") are:" + "\n";
    int k = this.asString().length() - 1;
    for (int i = weight.length() - 1; i >= 0; i--) {
      if (weight.charAt((i)) == '1')
        newWeight =newWeight + "1 " + "x " +  Integer.toString((int) (Math.pow(2 , (k - i)))) + " unit" + "\n";
    }
    return newWeight;
  }

  private int toInt(String s) {
    int newCons = 0;
    int k = s.length() - 1;
    if (isBinaryString(s)) {
      for (int i = 0; i < s.length(); i++) {
        if (s.charAt(i) == '1'  ) {
          newCons = (int) (newCons + Math.pow(2,  (k - i)));
        }
      }
    }
    return newCons;
  }

  public void increment() {
    int x = toInt(weight) + 1;
    weight =  toBinary(x);
  }

  public void decrement() {
    int x = toInt(weight) - 1;
    if (x < 0)
    weight =  "0";
    else
      weight = toBinary(x);
  }

  public BinaryWeight plus(BinaryWeight weight) {
    int x = weight.asDecimal();
    int y = this.asDecimal();
    int z = x + y;
  //or use x = toInt(this.weight);
    return new BinaryWeight(z);
  }
}
