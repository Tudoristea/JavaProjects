public class BinaryWeightClient {

  public static void main(String[] args) {
    // Add your example BinaryWeight objects below

    // Uncomment the following lines as you go
    BinaryWeight aWeight = new BinaryWeight( "10111");
    System.out.println("The value stored in the aWeight object is: " + aWeight.asString());
    // aWeight.increment();
    // aWeight.decrement();
    System.out.println(aWeight);
    System.out.println(aWeight.asString());
    //System.out.println(aWeight.asDecimal());
    //System.out.println("The value stored in the aWeight object is: " + aWeight.asString());

    //BinaryWeight three = new BinaryWeight("11");
    //System.out.println(three);

    //BinaryWeight seven = new BinaryWeight("111");
    //System.out.print(seven.asString() + " becomes ");
    //seven.increment();
    //System.out.print(seven.asString());

    //BinaryWeight two  = new BinaryWeight("010");
    //BinaryWeight four = new BinaryWeight("100");
    //BinaryWeight sum  = two.plus(four);
    //System.out.println(sum.asString());
  }
}
